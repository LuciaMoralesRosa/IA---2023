package aima.core.environment.CCL;

import java.util.LinkedHashSet;
import java.util.Set;

import aima.core.agent.Action;
import aima.core.search.framework.ActionsFunction;
import aima.core.search.framework.ResultFunction;

/**
 * @author Lucia Morales Rosa, 816906
 */

public class CCLFunctionFactory {
	private static ActionsFunction _actionsFunction = null;
	private static ResultFunction _resultFunction = null;

	public static ActionsFunction getActionsFunction() {
		if (null == _actionsFunction) {
			_actionsFunction = new CActionsFunction();
		}
		return _actionsFunction;
	}

	public static ResultFunction getResultFunction() {
		if (null == _resultFunction) {
			_resultFunction = new CResultFunction();
		}
		return _resultFunction;
	}

	private static class CActionsFunction implements ActionsFunction {
		public Set<Action> actions(Object state) {
			CCLBoard board = (CCLBoard) state;

			Set<Action> actions = new LinkedHashSet<Action>();

			if (board.hayMovimiento(CCLBoard.Lobo)) {
				actions.add(CCLBoard.Lobo);
			}
			if (board.hayMovimiento(CCLBoard.Cabra)) {
				actions.add(CCLBoard.Cabra);
			}
			if (board.hayMovimiento(CCLBoard.Col)) {
				actions.add(CCLBoard.Col);
			}
			if (board.hayMovimiento(CCLBoard.Barca)) {
				actions.add(CCLBoard.Barca);
			}
			return actions;
		}
	}

	private static class CResultFunction implements ResultFunction {
		public Object result(Object s, Action a) {
			CCLBoard board = (CCLBoard) s;

			if (CCLBoard.Lobo.equals(a)
					&& board.hayMovimiento(CCLBoard.Lobo)) {
				CCLBoard newBoard = new CCLBoard(board);
				newBoard.moverLobo();
				return newBoard;
			} else if (CCLBoard.Cabra.equals(a)
					&& board.hayMovimiento(CCLBoard.Cabra)) {
				CCLBoard newBoard = new CCLBoard(board);
				newBoard.moverCabra();

				return newBoard;
			}  else if (CCLBoard.Col.equals(a)
					&& board.hayMovimiento(CCLBoard.Col)) {
				CCLBoard newBoard = new CCLBoard(board);
				newBoard.moverCol();

				return newBoard;
			}  else if (CCLBoard.Barca.equals(a)
					&& board.hayMovimiento(CCLBoard.Barca)) {
				CCLBoard newBoard = new CCLBoard(board);
				newBoard.moverBarca();

				return newBoard;
			}

			// The Action is not understood or is a NoOp
			// the result will be the current state.
			return s;
		}
	}
}