package aima.core.environment.CCL;

import java.util.Arrays;

import aima.core.agent.Action;
import aima.core.agent.impl.DynamicAction;

/**
 * @author Lucia Morales Rosa, 816906
 */

public class CCLBoard {

	public static Action Lobo = new DynamicAction("Lobo");
	public static Action Cabra = new DynamicAction("Cabra");
	public static Action Col = new DynamicAction("Col");
	public static Action Barca = new DynamicAction("Barca");

	private int[] state;

	//
	// PUBLIC METHODS
	//

	public CCLBoard() {
		state = new int[] { 0, 0, 0, 0}; 	// state[0] = Lobo
											// state[1] = Cabra
											// state[2] = Col
											// state[3] = Barca
											// 0->Izda, 1->Dcha
	}

	public CCLBoard(int[] state) {
		this.state = new int[state.length];
		System.arraycopy(state, 0, this.state, 0, state.length);
	}

	public CCLBoard(CCLBoard copyBoard) {
		this(copyBoard.getState());
	}

	public int[] getState() {
		return state;
	}

	
	public void moverLobo() {
		state[0] = state[0] ^ 1;
		actualizarBarca();
	}

	public void moverCabra() {
		state[1] = state[1] ^ 1;
		actualizarBarca();
	}
	
	public void moverCol() {
		state[2] = state[2] ^ 1;
		actualizarBarca();
	}
	
	public void moverBarca() {
		actualizarBarca();
	}
	
	public boolean hayMovimiento(Action where) {
		boolean retVal = true;
		//Obtener estado de los objetos
		int b = state[3];
		int lobo = state[0];
		int cabra = state[1];	
		int col = state[2];
				
		if(where.equals(Lobo)) {
			retVal = (lobo == b && ((col == lobo && cabra != col) || (cabra == lobo && cabra != col)));
		}
		else if(where.equals(Cabra)) {
			retVal = (cabra == b);
		}
		else if(where.equals(Col)) {
			retVal = (col == b && ((col == lobo && cabra != lobo) || (cabra == col && cabra != lobo)));
		}
		else if(where.equals(Barca)) {
			retVal = (!(cabra == b && col == b) && !(cabra == b && lobo == b));
		}
		return retVal;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if ((o == null) || (this.getClass() != o.getClass())) {
			return false;
		}
		CCLBoard aBoard = (CCLBoard) o;
		return Arrays.equals(state, aBoard.state);
	}
	
	@Override
	public int hashCode() {
		int result = 17;
		for (int i = 0; i < 8; i++) {
			int position = this.getPositionOf(i);
			result = 37 * result + position;
		}
		return result;
	}

	@Override
	public String toString() {
		String retVal = "Orilla Izda - " + estaLobo(0) + " " + estaCabra(0) + " " + estaCol(0) +
				lugarBarca() + estaLobo(1) + " " + estaCabra(1) + " " + estaCol(1)+ " - Orilla Dcha";
		return retVal;
	}

	
	//
	// PRIVATE METHODS 
	//

	private int getPositionOf(int val) {
		int retVal = -1;
		for (int i = 0; i < 4; i++) {
			if (state[i] == val) {
				retVal = i;
			}
		}
		return retVal;
	}
	
	private String lugarBarca() {
		String retVal = "";
		switch(state[3]) {
		case 0:
			retVal = " BARCA --RIO--         ";
			break;
		case 1:
			retVal = "       --RIO-- BARCA   ";
			break;
		}
		return retVal;
	}
	
	private String estaLobo(int orilla) {
		String retVal = "  ";
		if(orilla == state[0]) {
			retVal = "L ";
		}		
		return retVal;
	}
	
	private String estaCabra(int orilla) {
		String retVal = "  ";
		if(orilla == state[1]) {
			retVal = "C ";
		}		
		return retVal;
	}
	
	private String estaCol(int orilla) {
		String retVal = "  ";
		if(orilla == state[2]) {
			retVal = "c ";
		}		
		return retVal;
	}
	
	private void actualizarBarca() {
		state[3] = state[3] ^ 1;
	}
	
	
}