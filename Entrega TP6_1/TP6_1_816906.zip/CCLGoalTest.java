package aima.core.environment.CCL;

import aima.core.search.framework.GoalTest;

/**
 * @author Lucia Morales Rosa, 816906
 */

public class CCLGoalTest implements GoalTest {
	CCLBoard goal = new CCLBoard(new int[] { 1, 1, 1, 1});

	public boolean isGoalState(Object state) {
		CCLBoard board = (CCLBoard) state;
		return board.equals(goal);
	}
}