package aima.gui.demo.search;

import java.util.List;

import aima.core.agent.Action;
import aima.core.environment.CCL.CCLBoard;
import aima.core.environment.CCL.CCLFunctionFactory;
import aima.core.environment.CCL.CCLGoalTest;
import aima.core.search.framework.GraphSearch;
import aima.core.search.framework.Problem;
import aima.core.search.framework.ResultFunction;
import aima.core.search.framework.Search;
import aima.core.search.framework.SearchAgent;
import aima.core.search.uninformed.IterativeDeepeningSearch;
import aima.core.search.uninformed.BreadthFirstSearch;

/**
 * @author Lucia Morales Rosa, 816906
 */

public class CCLApp {
	static CCLBoard CCLTablero = new CCLBoard(
			new int[] {0, 0, 0, 0});

	public static void main(String[] args) {
		CCLBusqueda(new IterativeDeepeningSearch(), CCLTablero, "IDLS");
		System.out.println();
		CCLBusqueda(new BreadthFirstSearch(new GraphSearch()), CCLTablero, "BFS");
		
	}

	private static void CCLBusqueda(Search busqueda, CCLBoard estado, String problema) {
		try {
			System.out.println("Problema CCL " + problema + ": ");
			long t1 = System.currentTimeMillis();
			Problem p = new Problem(estado, CCLFunctionFactory.getActionsFunction(),
					CCLFunctionFactory.getResultFunction(), new CCLGoalTest());
			
			Search s = busqueda;
			SearchAgent agent = new SearchAgent(p, s);
			List<Action> actions = agent.getActions();
		
		
			//Valores a mostrar:
			String pathCost = "pathCost : " + agent.getInstrumentation().getProperty("pathCost");
			int nodosExpandidos;
			if(agent.getInstrumentation().getProperty("nodesExpanded") == null) {
				nodosExpandidos = 0;
			}
			else {
				nodosExpandidos = (int)Float.parseFloat(agent.getInstrumentation().getProperty("nodesExpanded"));
			}
			String nodesExpanded = "nodesExpanded : " + nodosExpandidos;
			int colaTam;
			if (agent.getInstrumentation().getProperty("queueSize") == null) {
				colaTam = 0;
			}
			else {
				colaTam =	(int)Float.parseFloat(agent.getInstrumentation().getProperty("queueSize"));
			}
			String queueSize = "queueSize : " + colaTam;
			int maximo;		
			if (agent.getInstrumentation().getProperty("maxQueueSize") == null) {
				maximo= 0;				
			}
			else {
				maximo = (int)Float.parseFloat(agent.getInstrumentation().getProperty("maxQueueSize"));
			}
			String maxQueueSize = "maxQueueSize : " + maximo;
			long t2 = System.currentTimeMillis();
			long t = t2 - t1;
			
			System.out.println(pathCost);
			System.out.println(nodesExpanded);
			if(problema == "BFS") {
				System.out.println(queueSize);
				System.out.println(maxQueueSize);
			}
			System.out.println("TIEMPO : " + t + '\n');
			
			System.out.println("SOLUCIÓN: \nGOAL STATE :" );
			System.out.println("\t\t\tOrilla Izda -                --RIO-- BARCA   L  C  c  - Orilla Dcha\nCAMINO ENCONTRADO");
			acciones(actions, p);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void acciones(List<Action> acciones, Problem p) {
		Object estadoInicial = p.getInitialState();
		ResultFunction resultado = p.getResultFunction();
		Object estado = estadoInicial;
		System.out.printf("%19s", "ESTADO INICIAL \t");
		System.out.println(estado);
		for(Action action : acciones) {
			System.out.printf("%18s\t", action.toString());
			estado = resultado.result(estado, action);
			System.out.println(estado);
			//System.out.println("- - -");
		}
	}
	
	

}