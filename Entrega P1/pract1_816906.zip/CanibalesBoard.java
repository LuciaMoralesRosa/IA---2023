package aima.core.environment.canibales;

import java.util.Arrays;
import aima.core.agent.Action;
import aima.core.agent.impl.DynamicAction;

/**
 * @author Lucia Morales Rosa, 816906
 */

public class CanibalesBoard {

	public static Action Can1 = new DynamicAction("1Can");
	public static Action Can2 = new DynamicAction("2Can");
	public static Action Mis1 = new DynamicAction("1Mis");
	public static Action Mis2 = new DynamicAction("2Mis");
	public static Action Can1Mis1 = new DynamicAction("1Can1Mis");


	private int[] state;

	//
	// PUBLIC METHODS
	//

	public CanibalesBoard() {
		state = new int[] {3, 3, 0, 0, 0}; // state[0] = numCanibalesIzda
											// state[1] = numMisionerosIzda
											// state[2] = Posicion barca (0 izda, 1 dcha)
											// state[3] = numCanibalesDcha
											// state[4] = numMisionerosDcha
	}

	public CanibalesBoard(int[] state) {
		this.state = new int[state.length];
		System.arraycopy(state, 0, this.state, 0, state.length);
	}

	public CanibalesBoard(CanibalesBoard copyBoard) {
		this(copyBoard.getState());
	}

	public int[] getState() {
		return state;
	}

	public void mover1Canibal() {
		int b = getPosBarca(); //0-> izda, 1->dcha
		actualizarCanibales(b, 1);	
		actualizarBarca(b);
	}

	
	public void mover2Canibal() {
		int b = getPosBarca(); //0-> izda, 1->dcha
		actualizarCanibales(b, 2);
		actualizarBarca(b);
	}
	
	public void mover1Misionero() {
		int b = getPosBarca(); //0-> izda, 1->dcha
		actualizarMisioneros(b, 1);	
		actualizarBarca(b);
	}
	
	public void mover2Misionero() {
		int b = getPosBarca(); //0-> izda, 1->dcha
		actualizarMisioneros(b, 2);	
		actualizarBarca(b);
	}
	
	public void mover1Misionero1Canibal() {
		int b = getPosBarca(); //0-> izda, 1->dcha
		actualizarCanibales(b, 1);
		actualizarMisioneros(b, 1);
		actualizarBarca(b);
	}
	
	public boolean hayMovimiento(Action where) {
		boolean retVal = true;
		//Obtener estado de los objetos
		int b = getPosBarca();
		int canIzda = getCanibales(0);
		int canDcha = getCanibales(1);	
		int misIzda = getMisioneros(0);
		int misDcha = getMisioneros(1);
		
		if(where.equals(Can1)) {
			switch(b) {
			case 0: //Desde izda
				retVal = (canIzda >= 1 && (misDcha >= canDcha + 1 || misDcha == 0)); 
				break;
			case 1:	
				retVal = (canDcha >= 1 && (misIzda >= canIzda + 1 || misIzda == 0)); //Desde dcha
				break;
			}	
		}
		else if(where.equals(Can2)) {
			switch(b) {
			case 0:
				retVal = (canIzda >= 2 && (misDcha >= canDcha + 2 || misDcha == 0)); //Desde izda
				break;
			case 1:
				retVal = (canDcha >= 2 && (misIzda >= canIzda + 2 || misIzda == 0)); //Desde dcha
				break;
			}
		}
		else if(where.equals(Mis1)) {
			switch(b) {
			case 0:
				retVal = (misIzda >= 1 && ((misIzda >= canIzda + 1 || misIzda == 1) && misDcha >= canDcha - 1)); //Desde izda
				break;
			case 1:
				retVal = (misDcha >= 1 && ((misDcha >= canDcha + 1 || misDcha == 1) && misIzda >= canIzda - 1)); //Desde dcha
				break;
			}
		}else if(where.equals(Mis2)) {
			switch(b){
			case 0:
				retVal = (misIzda >= 2 && ((misIzda >= canIzda + 2 || misIzda == 2) && misDcha >= canDcha - 2)); //Desde izda
				break;
			case 1:
				retVal = (misDcha >= 2 && ((misDcha >= canDcha + 2 || misDcha == 2) && misIzda >= canIzda - 2)); //Desde dcha
				break;
			}
		}
		else if(where.equals(Can1Mis1)) {
			switch(b) {
			case 0:
				retVal = (canIzda >= 1 && misIzda >= 1 && misDcha >= canDcha); //Desde izda
				break;
			case 1:
				retVal = (canDcha >= 1 && misDcha >= 1 && misIzda >= canIzda); //Desde dcha
				break;
			}
		}
		return retVal;
	}

	@Override
	public boolean equals(Object o) {

		if (this == o) {
			return true;
		}
		if ((o == null) || (this.getClass() != o.getClass())) {
			return false;
		}
		CanibalesBoard aBoard = (CanibalesBoard) o;
		return Arrays.equals(state, aBoard.state);
	}


	
	@Override
	public int hashCode() {
		int result = 17;
		for (int i = 0; i < 8; i++) {
			int position = this.getPositionOf(i);
			result = 37 * result + position;
		}
		return result;
	}

	@Override
	public String toString() {
		String retVal = "Orilla Izda - " + numMisioneros(0) + numCanibales(0) + " " +
				lugarBarca() + numMisioneros(1) + numCanibales(1) + " - Orilla Dcha";
		return retVal;
	}

	
	
	//
	// PRIVATE METHODS --------------------------------------------------------------
	//

	private int getPositionOf(int val) {
		int retVal = -1;
		for (int i = 0; i < 5; i++) {
			if (state[i] == val) {
				retVal = i;
			}
		}
		return retVal;
	}
	
	private int getPosBarca() {
		return state[2];
	}

	private String lugarBarca() {
		String retVal = "";
		switch(state[2]) {
		case 0:
			retVal = " BARCA --RIO--         ";
			break;
		case 1:
			retVal = "       --RIO-- BARCA   ";
			break;
		}
		return retVal;
	}
	
	private String numMisioneros(int orilla){
		String retVal = "      ";
		int mis = 0;
		switch(orilla) {
		case 0: //Orilla izquierda
			mis = state[0];
			break;
		case 1: //Orilla derecha
			mis = state[3];
			break;
		}
		switch(mis) {
		case 1:
			retVal = "M     ";
			break;
		case 2:
			retVal = "M M   ";
			break;
		case 3: 
			retVal = "M M M ";
			break;
		}
		return retVal;
	}

	private String numCanibales(int orilla){
		String retVal = "      ";
		int can = 0;
		switch(orilla) {
		case 0: //Orilla izquierda
			can = state[1];
			break;
		case 1: //Orilla derecha
			can = state[4];
			break;
		}
		switch(can) {
		case 1:
			retVal = "C     ";
			break;
		case 2:
			retVal = "C C   ";
			break;
		case 3: 
			retVal = "C C C ";
			break;
		}
		return retVal;
	}
	
	private int getCanibales(int orilla) {
		int canibales = 0;
		switch(orilla){
		case 0: //Izda
			canibales = state[1];
			break;
		case 1: //dcha
			canibales = state[4];
			break;
		}
		return canibales;
	}
	
	private int getMisioneros(int orilla) {
		int misioneros = 0;
		switch(orilla){
		case 0: //Izda
			misioneros = state[0];
			break;
		case 1: //dcha
			misioneros = state[3];
			break;
		}
		return misioneros;
	}
	
	private void actualizarBarca(int origen) {
		switch(origen) {
		case 0:
			state[2] = 1;
			break;
		case 1:
			state[2] = 0;
			break;
		}
	}
	
	private void actualizarCanibales(int origen, int num) {
		switch(origen) {
		case 0: //Estan en la izda
			state[1] = state[1] - num;
			state[4] = state[4] + num;
			break;
		case 1: //Estan en la dcha
			state[1] = state[1] + num;
			state[4] = state[4] - num;
			break;
		}
	}
	
	private void actualizarMisioneros(int origen, int num) {
		switch(origen) {
		case 0:
			state[0] = state[0] - num;
			state[3] = state[3] + num;
			break;
		case 1:
			state[0] = state[0] + num;
			state[3] = state[3] - num;
			break;
		}
	}
	
}