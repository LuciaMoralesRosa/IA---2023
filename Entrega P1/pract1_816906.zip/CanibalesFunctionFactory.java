package aima.core.environment.canibales;

import java.util.LinkedHashSet;
import java.util.Set;

import aima.core.agent.Action;
import aima.core.search.framework.ActionsFunction;
import aima.core.search.framework.ResultFunction;

/**
 * @author Lucia Morales Rosa, 816906
 */

public class CanibalesFunctionFactory {
	private static ActionsFunction _actionsFunction = null;
	private static ResultFunction _resultFunction = null;

	public static ActionsFunction getActionsFunction() {
		if (null == _actionsFunction) {
			_actionsFunction = new CActionsFunction();
		}
		return _actionsFunction;
	}

	public static ResultFunction getResultFunction() {
		if (null == _resultFunction) {
			_resultFunction = new CResultFunction();
		}
		return _resultFunction;
	}

	private static class CActionsFunction implements ActionsFunction {
		public Set<Action> actions(Object state) {
			CanibalesBoard board = (CanibalesBoard) state;

			Set<Action> actions = new LinkedHashSet<Action>();

			if (board.hayMovimiento(CanibalesBoard.Can1)) {
				actions.add(CanibalesBoard.Can1);
			}
			if (board.hayMovimiento(CanibalesBoard.Can2)) {
				actions.add(CanibalesBoard.Can2);
			}
			if (board.hayMovimiento(CanibalesBoard.Mis1)) {
				actions.add(CanibalesBoard.Mis1);
			}
			if (board.hayMovimiento(CanibalesBoard.Mis2)) {
				actions.add(CanibalesBoard.Mis2);
			}
			if (board.hayMovimiento(CanibalesBoard.Can1Mis1)) {
				actions.add(CanibalesBoard.Can1Mis1);
			}

			return actions;
		}
	}

	private static class CResultFunction implements ResultFunction {
		public Object result(Object s, Action a) {
			CanibalesBoard board = (CanibalesBoard) s;

			if (CanibalesBoard.Can1.equals(a)
					&& board.hayMovimiento(CanibalesBoard.Can1)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.mover1Canibal();
				return newBoard;
			} else if (CanibalesBoard.Can2.equals(a)
					&& board.hayMovimiento(CanibalesBoard.Can2)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.mover2Canibal();
				return newBoard;
			}  else if (CanibalesBoard.Mis1.equals(a)
					&& board.hayMovimiento(CanibalesBoard.Mis1)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.mover1Misionero();
				return newBoard;
			}  else if (CanibalesBoard.Mis2.equals(a)
					&& board.hayMovimiento(CanibalesBoard.Mis2)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.mover2Misionero();
				return newBoard;
			}  else if (CanibalesBoard.Can1Mis1.equals(a)
					&& board.hayMovimiento(CanibalesBoard.Can1Mis1)) {
				CanibalesBoard newBoard = new CanibalesBoard(board);
				newBoard.mover1Misionero1Canibal();
				return newBoard;
			} 

			// The Action is not understood or is a NoOp
			// the result will be the current state.
			return s;
		}
	}
}